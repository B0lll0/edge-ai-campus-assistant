# Ai_Datset — MSA University Offline Edge AI Campus Assistant RAG Dataset

Complete bilingual (English & Arabic) RAG dataset and persistent ChromaDB vector store for **MSA University (6th of October City)** plus **AI & Microprocessors course lectures, labs, tutorials, and notes** imported from `C:\campus_assistant`, prepared for offline Edge AI deployment (Raspberry Pi 3/4/5 + Ollama + ChromaDB + Whisper + Flask).

## Live Dataset Summary

- **Total Sources:** 54 documents (10 official MSA University campus, tuition & admission guides + 44 AI, Microprocessors & Project PDFs)
- **RAG Chunks:** 826 overlapping text chunks
- **Q&A Pairs:** 245 bilingual & course Q&A records
- **ChromaDB Vectors:** 1071 live vectors

## Folder Structure

- `raw_documents/` — Clean UTF-8 Markdown source files for MSA University (Overview, Academic Rules, Campus Buildings, Rooms & Locations, Food Court, Top 5 Internet FAQs, Study Plans for all 11 faculties, and Arabic Guide)
- `exports/` — RAG-ready structured datasets (including all imported AI & Microprocessors lectures, labs, and tutorials):
  - `rag_chunks_chromadb.json` — 826 overlapping RAG chunks with metadata ready for `nomic-embed-text` + ChromaDB
  - `qa_dataset.jsonl` — 245 instruction/response Q&A pairs for RAG evaluation or LLM fine-tuning
  - `campus_dataset.csv` — UTF-8 BOM Excel-compatible combined spreadsheet (Arabic-safe)
  - `dataset_store.json` — Complete combined Flask store (`sources`, `chunks`, `qa_pairs`)
  - `msa_structured_knowledge.json` — Structured JSON of all 11 faculties, 27 majors, 4/5-year plans, buildings, Gate 1–4 directions, and Top 5 FAQs
  - `msa_top_5_faqs.json` — Top 5 frequently asked MSA University questions
- `chroma_db/` — Pre-built **Persistent ChromaDB** vector database (1071 live vectors) ready to query immediately
- `scripts/` — Ready-to-run RAG ingestion and Raspberry Pi deployment scripts:
  - `ingest_chromadb.py` — Ingest `exports/rag_chunks_chromadb.json` into ChromaDB using Ollama `nomic-embed-text`
  - `import_campus_assistant.py` — Re-import MSA docs + `C:\campus_assistant` course PDFs into `data/dataset_store.json` and ChromaDB
  - `deploy_raspberry_pi.sh` — Turnkey Raspberry Pi 3/4/5 installer (Flask + ChromaDB + Ollama + espeak-ng)
  - `kiosk_start.sh` — 7-inch touch display Chromium Kiosk Mode launcher

## Quick RAG Usage (ChromaDB + Ollama)

```bash
pip install chromadb requests
ollama pull nomic-embed-text
ollama pull phi3:mini
python scripts/ingest_chromadb.py --input exports/rag_chunks_chromadb.json --db ./chroma_db_nomic
```
