# MSA University Complete Faculties, Majors, and 4/5 Year Study Plans

## Faculty of Engineering (5 year plan)
University of Greenwich dual degree · Building C (Building 3) & Workshops Building 6

### Architectural Systems Engineering (ASE) · Five Year Study Plan
• Year 1 (Foundation): Engineering Mathematics 1 & 2, Engineering Physics 1 & 2, Engineering Chemistry, Mechanics 1 & 2, Engineering Drawing, Computing Basics, Production Technology, Academic English.
• Year 2: Architectural Design 1 & 2, History and Theories of Architecture 1, Building Construction 1 & 2, Descriptive Geometry, Visual Studies & Freehand Drawing, Surveying, Computer Graphics (CAD/BIM).
• Year 3: Architectural Design 3 & 4, Structural Analysis & Reinforced Concrete, Environmental Control Systems, Building Acoustics & Lighting, Urban Design Basics, History & Theories 2, Working Drawings 1.
• Year 4: Architectural Design 5 & 6, Urban Planning & Housing, Landscape Architecture, Interior Architecture, Sustainable & Earth Architecture (CSEB), Working Drawings 2, Construction Management & Quantities.
• Year 5: Advanced Architectural Design Studio, Professional Practice & Building Laws, Heritage Conservation, Advanced BIM & Parametric Design, Senior Graduation Project 1 & 2, Field Training.

### Computer Systems Engineering (CSE) · Five Year Study Plan
• Year 1 (Foundation): Engineering Mathematics 1 & 2, Engineering Physics 1 & 2, Engineering Chemistry, Mechanics, Engineering Drawing, Programming Fundamentals, Production Tech, Academic English.
• Year 2: Linear Algebra & Differential Equations, Discrete Mathematics, Electric Circuits 1 & 2, Digital Logic Design, Object Oriented Programming, Data Structures & Algorithms, Electronics 1, Probability & Statistics.
• Year 3: Computer Organization & Architecture, Microprocessors & Assembly, Operating Systems, Signals & Systems, Database Systems, Computer Networks, Software Engineering, Embedded Systems 1.
• Year 4: Embedded Systems 2 (Edge AI & Microcontrollers), Digital Signal Processing, Machine Learning & Pattern Recognition, VLSI & FPGA Design, Real Time Systems, Computer Vision, Compilers.
• Year 5: Distributed & Cloud Computing, Cybersecurity & Network Security, IoT Systems Architecture, Robotics & Autonomous Systems, Engineering Management, Senior Graduation Project 1 & 2, Industrial Training.

### Electrical Communication & Electronic Systems (ECE) · Five Year Study Plan
• Year 1 (Foundation): Engineering Mathematics 1 & 2, Engineering Physics 1 & 2, Engineering Chemistry, Mechanics, Engineering Drawing, Computing Basics, Production Tech, Academic English.
• Year 2: Complex Analysis & Differential Equations, Electric Circuits 1 & 2, Electromagnetics 1, Digital Logic Design, Semiconductor Physics, Electronics 1, C++ Programming, Probability & Random Variables.
• Year 3: Signals & Systems, Analog Communication Systems, Electronics 2 (Analog IC), Electromagnetics 2 & Transmission Lines, Microprocessors, Control Systems, Measurements & Instrumentation.
• Year 4: Digital Communications, Digital Signal Processing (DSP), Antennas & Wave Propagation, Microwave Engineering, Optical Fiber Communications, Embedded Systems, Wireless & Mobile Networks (4G/5G).
• Year 5: Satellite & Radar Systems, RF Circuit Design, Information Theory & Coding, IoT & Smart Communication Networks, Engineering Economics, Senior Graduation Project 1 & 2, Field Training.

### Industrial Systems Engineering (ISE) · Five Year Study Plan
• Year 1 (Foundation): Engineering Mathematics 1 & 2, Engineering Physics 1 & 2, Engineering Chemistry, Mechanics, Engineering Drawing, Computing Basics, Production Tech, Academic English.
• Year 2: Engineering Statistics & Probability, Materials Science, Manufacturing Processes, Thermodynamics, Work Study & Ergonomics, Engineering Economics, Computer Aided Design.
• Year 3: Operations Research 1 & 2, Production Planning & Control, Quality Control & Six Sigma, Facilities Planning & Layout, Cost Accounting for Engineers, Industrial Automation.
• Year 4: Supply Chain & Logistics Management, System Simulation & Modeling, Reliability & Maintenance Engineering, Project Management, Lean Manufacturing, Human Factors Engineering.
• Year 5: Enterprise Resource Planning (ERP), Decision Analysis & Optimization, Industrial Safety & Sustainability, Data Analytics for Industry 4.0, Senior Graduation Project 1 & 2, Industrial Training.

### Mechatronics Systems Engineering (MSE) · Five Year Study Plan
• Year 1 (Foundation): Engineering Mathematics 1 & 2, Engineering Physics 1 & 2, Engineering Chemistry, Mechanics, Engineering Drawing, Computing Basics, Production Tech, Academic English.
• Year 2: Dynamics & Kinematics, Mechanics of Materials, Electric Circuits, Digital Logic Design, Electronics, Materials Science, CAD & 3D Modeling, C++ Programming.
• Year 3: Theory of Machines, Fluid Mechanics & Hydraulics, Thermodynamics, Sensors & Actuators, Microcontrollers & Interfacing, Control Systems 1, Machine Design 1.
• Year 4: Robotics Kinematics & Dynamics, PLC & Industrial Automation, Power Electronics & Electric Drives, Embedded Mechatronic Systems, Control Systems 2 (Digital Control), Mechanical Vibrations.
• Year 5: Autonomous Vehicles & Drones, AI & Computer Vision in Robotics, Mechatronic System Design, Pneumatics & Smart Manufacturing, Senior Graduation Project 1 & 2, Industrial Training.

## Faculty of Computer Science (4 year plan (140 credits))
University of Greenwich dual degree · Building C (Building 3), Building K & Building G

### Computer Science Pathway (CSP) · Four Year Study Plan (140 Credits)
• Year 1: Introduction to Computer Science, Structured Programming, Object Oriented Programming, Calculus 1 & 2, Discrete Mathematics, Physics, Digital Logic, Academic English.
• Year 2: Data Structures, Design & Analysis of Algorithms, Computer Organization & Architecture, Database Management Systems, Linear Algebra, Probability & Statistics, Operating Systems, Systems Analysis.
• Year 3: Artificial Intelligence, Machine Learning, Computer Networks, Theory of Computation, Compiler Construction, Human Computer Interaction, Software Engineering, Parallel Computing.
• Year 4: Deep Learning & Neural Networks, Natural Language Processing, Computer Vision, Big Data Analytics, Cybersecurity, Graduation Project 1 & 2, Specialized CS Electives.

### Software Engineering Pathway (SEP) · Four Year Study Plan (140 Credits)
• Year 1: Introduction to CS, Structured Programming, Object Oriented Programming, Calculus 1 & 2, Discrete Mathematics, Digital Logic, Physics, Academic English.
• Year 2: Data Structures, Algorithms, Database Systems, Systems Analysis & Design, Software Engineering 1, Operating Systems, Linear Algebra, Probability & Statistics.
• Year 3: Software Architecture & Design Patterns, Requirements Engineering, Software Testing & Quality Assurance, Web & Mobile App Development, Computer Networks, Human Computer Interaction.
• Year 4: Agile & DevOps Engineering, Software Project Management, Cloud Native Systems, Formal Methods & Verification, Secure Software Development, Graduation Project 1 & 2.

### Internet Computing Pathway (ICP) · Four Year Study Plan (140 Credits)
• Year 1: Introduction to CS, Structured Programming, Object Oriented Programming, Calculus 1 & 2, Discrete Mathematics, Digital Logic, Physics, Academic English.
• Year 2: Data Structures, Algorithms, Web Technologies 1, Database Systems, Computer Networks 1, Operating Systems, Linear Algebra, Statistics.
• Year 3: Full Stack Web Engineering, Distributed Systems, Computer Networks 2 & Routing, Network Security, Mobile Computing, Cloud Infrastructure, API & Microservices Design.
• Year 4: Internet of Things (IoT), Edge & Fog Computing, Ethical Hacking & Cyber Defense, Scalable Web Architectures, E Commerce Systems, Graduation Project 1 & 2.

## Faculty of Biotechnology (4 year plan)
University of Greenwich dual degree · Building C (Building 3) & Labs Building D (Building 4)

### Medical & Pharmaceutical Biotechnology · Four Year Study Plan
• Year 1: General Biology 1 & 2, General & Organic Chemistry, Cell Biology, Biophysics, Mathematics & Biostatistics, Introduction to Biotechnology, Academic English.
• Year 2: Biochemistry 1 & 2, General Microbiology, Genetics, Human Physiology, Molecular Biology 1, Analytical Chemistry, Biosafety & Lab Techniques.
• Year 3: Genetic Engineering & Recombinant DNA, Immunology, Virology, Molecular Diagnostics, Stem Cell Biology, Pharmacology Basics, Bioinformatics 1.
• Year 4: Biopharmaceuticals & Vaccine Design, Cancer Molecular Biology, Gene Therapy & CRISPR, Genomics & Proteomics, Clinical Trials & Bioethics, Graduation Research Project 1 & 2.

### Industrial & Environmental Biotechnology · Four Year Study Plan
• Year 1: General Biology 1 & 2, General & Organic Chemistry, Cell Biology, Biophysics, Biostatistics, Introduction to Biotechnology, Academic English.
• Year 2: Biochemistry 1 & 2, General Microbiology, Genetics, Plant Biology, Molecular Biology 1, Analytical Chemistry, Lab Instrumentation.
• Year 3: Fermentation & Bioprocess Technology, Enzyme Technology, Plant Tissue Culture, Environmental Microbiology, Microbial Genetics, Bioinformatics.
• Year 4: Bioremediation & Waste Treatment, Biofuels & Renewable Bioproducts, Agricultural Genetic Improvement, Quality Control & GMP, Entrepreneurship in Biotech, Graduation Project 1 & 2.

## Faculty of Pharmacy (5 year plan + Internship)
University of Greenwich dual degree · Building C (Building 3), Building D (Labs) & Building K

### PharmD General Pharmacy · Five Year Study Plan + Internship
• Year 1: Pharmaceutical Organic Chemistry 1 & 2, Analytical Chemistry, Cell Biology, Human Anatomy & Histology, Medicinal Plants, Medical Terminology, Pharmacy Orientation, Academic English.
• Year 2: Physical Pharmacy, Pharmaceutics 1, Biochemistry 1 & 2, Physiology, Pathophysiology, Pharmacognosy 1 & 2, General Microbiology & Immunology.
• Year 3: Pharmaceutics 2 & 3, Pharmacology 1 & 2, Medicinal Chemistry 1 & 2, Pharmaceutical Microbiology, Phytochemistry, Instrumental Analysis, Biostatistics.
• Year 4: Biopharmaceutics & Pharmacokinetics, Industrial Pharmacy, Clinical Pharmacy 1, Toxicology, Drug Design, Quality Control & GMP, Pharmaceutical Legislation.
• Year 5: Pharmacotherapy 1 & 2, Hospital Pharmacy, Drug Marketing & Management, Bioequivalence & Research Project, Community Pharmacy Practice, followed by 1 Year Pre Registration Internship.

### PharmD Clinical Pharmacy · Five Year Study Plan + Internship
• Year 1: Pharmaceutical Organic Chemistry 1 & 2, Analytical Chemistry, Anatomy & Histology, Cell Biology, Medical Terminology, Pharmacy Orientation, Academic English.
• Year 2: Physiology, Pathophysiology, Biochemistry 1 & 2, Physical Pharmacy, Pharmaceutics 1, Microbiology & Immunology, Pharmacognosy.
• Year 3: Pharmacology 1 & 2, Medicinal Chemistry 1 & 2, Pharmaceutics 2, Clinical Biochemistry, Communication Skills in Healthcare, Evidence Based Medicine.
• Year 4: Clinical Pharmacokinetics, Pharmacotherapy 1 & 2 (Cardiology, Endocrinology, Infectious Diseases), Clinical Toxicology, Hospital Pharmacy, Drug Information & Literature Evaluation.
• Year 5: Advanced Pharmacotherapy 3 & 4 (Oncology, Critical Care, Pediatrics, Nephrology), Clinical Nutrition, Patient Counseling & Ward Rounds, Graduation Research Project, followed by 1 Year Clinical Internship.

## Faculty of Dentistry (5 year plan + Internship)
Supreme Council of Universities accredited · Building C (Building 3), Building D Clinics, Building H & Building 11

### Oral and Dental Medicine & Surgery · Five Year Study Plan + Internship
• Year 1: Human Anatomy, General Histology, General Physiology, Biochemistry, Dental Anatomy & Morphology, Dental Biomaterials 1, Behavioral Sciences, Academic English.
• Year 2: Head & Neck Anatomy, Oral Biology & Oral Histology, General Pathology, Microbiology & Immunology, General Pharmacology, Dental Biomaterials 2, Preclinical Operative & Prosthodontics.
• Year 3: Oral Pathology, General Medicine, General Surgery, Preclinical Endodontics, Preclinical Fixed Prosthodontics, Oral Radiology, Local Anesthesia & Exodontia.
• Year 4: Clinical Operative Dentistry, Clinical Endodontics, Removable & Fixed Prosthodontics, Periodontology & Oral Medicine, Oral & Maxillofacial Surgery 1, Pediatric Dentistry 1, Orthodontics 1.
• Year 5: Advanced Comprehensive Clinical Care, Oral & Maxillofacial Surgery 2, Implantology & Laser Dentistry, Orthodontics 2, Pediatric Dentistry 2, Practice Management & Ethics, Graduation Project, followed by 1 Year Clinical Internship.

## Faculty of Physical Therapy (5 year plan (195 credits) + Internship)
University of Bedfordshire dual degree · Building M (Room M108 & 11 specialized clinical labs)

### Faculty of Physical Therapy · Five Year Study Plan (195 Credits) + Internship
• Year 1: Human Anatomy 1 & 2, Histology, Physiology 1 & 2, Biophysics, Biochemistry, Psychology, Medical Terminology, Academic English.
• Year 2: Neuroanatomy, Biomechanics & Kinesiology, Pathology, Pharmacology, Therapeutic Exercise 1, Electrotherapy 1, Hydrotherapy, Tests & Measurements.
• Year 3: Orthopedics & Traumatology PT, Manual Therapy, Electrotherapy 2, Exercise Physiology, Internal Medicine & Cardiopulmonary PT, Medical Imaging, Clinical Practice 1.
• Year 4: Neurology & Neurosurgery PT, Pediatrics & Developmental PT, General Surgery & Burn Rehabilitation, Women's Health & Obstetrics PT, Geriatrics PT, Clinical Practice 2.
• Year 5: Sports Injuries & Motion Analysis Lab, Differential Diagnosis, Evidence Based Practice & Research Methods, Intensive Hospital Clinical Rotations, Graduation Research Project, followed by Mandatory 1 Year Clinical Internship.

## Faculty of Management Sciences (4 year plan (Levels 1 to 4))
University of Greenwich dual degree · Building A (Building 1)

### Accounting · Four Year Study Plan (Levels 1 to 4)
• Year 1 (Common Foundation): Principles of Management, Microeconomics, Macroeconomics, Financial Accounting 1, Business Mathematics, Business Statistics, Computing for Business, Academic English.
• Year 2 (Common + Core): Financial Accounting 2, Cost Accounting, Principles of Finance, Marketing Principles, Business Law, Organizational Behavior, Operations Management, Management Accounting.
• Year 3: Intermediate Financial Accounting 1 & 2, Auditing & Assurance, Tax Accounting, Accounting Information Systems (AIS), Corporate Finance, Financial Statement Analysis.
• Year 4: Advanced Financial Accounting, International Accounting Standards (IFRS), Forensic Accounting, Strategic Management, Research Methods, Senior Graduation Project.

### Finance & Investment Management · Four Year Study Plan
• Year 1 (Common Foundation): Principles of Management, Microeconomics, Macroeconomics, Financial Accounting 1, Business Math, Statistics, Business Computing, Academic English.
• Year 2: Financial Accounting 2, Corporate Finance 1, Money & Banking, Marketing, Business Law, Quantitative Methods, Organizational Behavior.
• Year 3: Investment & Portfolio Management, Financial Markets & Institutions, Financial Statement Analysis, International Finance, Risk Management & Insurance, Financial Modeling.
• Year 4: Derivatives & Fixed Income Securities, Islamic Banking & FinTech, Mergers & Acquisitions, Strategic Financial Management, Research Methods, Senior Graduation Project.

### Marketing & International Business · Four Year Study Plan
• Year 1 (Common Foundation): Principles of Management, Microeconomics, Macroeconomics, Financial Accounting, Business Math & Statistics, Business Computing, Academic English.
• Year 2: Principles of Marketing, Consumer Behavior, Corporate Finance, Human Resources, Business Law, Operations Management, Business Communications.
• Year 3: Marketing Research, Digital & Social Media Marketing, Integrated Marketing Communications (IMC), Brand Management, International Business, Services Marketing.
• Year 4: Global Marketing Strategy, B2B Marketing & Sales Management, Retail & Supply Chain Marketing, Entrepreneurship, Strategic Management, Senior Graduation Project.

### Management Information Systems (MIS) · Four Year Study Plan
• Year 1 (Common Foundation): Principles of Management, Microeconomics, Macroeconomics, Financial Accounting, Business Math & Statistics, Intro to Information Systems, Academic English.
• Year 2: Business Programming, Database Management Systems, Systems Analysis & Design, Marketing, Finance, Operations Management, Organizational Behavior.
• Year 3: Enterprise Resource Planning (ERP), Business Intelligence & Data Analytics, E Business & Digital Transformation, Web Application Development, Networking & Cloud for Business.
• Year 4: Information Security & Governance, IT Project Management, Decision Support Systems, Digital Strategy & Innovation, Research Methods, Senior Graduation Project.

### Human Resources Management & Economics · Four Year Study Plan
• Year 1 (Common Foundation): Principles of Management, Microeconomics, Macroeconomics, Financial Accounting, Business Math & Statistics, Business Computing, Academic English.
• Year 2: Organizational Behavior, Human Resource Management 1, Intermediate Micro & Macroeconomics, Business Law, Finance, Marketing, Quantitative Analysis.
• Year 3: Talent Acquisition & Recruitment, Training & Development, Compensation & Benefits, Labor Economics & Econometrics, International Economics, Performance Management.
• Year 4: Strategic HRM, Organizational Change & Leadership, Economic Policy & Development, Industrial Relations, Research Methods, Senior Graduation Project.

## Faculty of Mass Communication (4 year plan)
University of Bedfordshire dual degree · Building A (Building 1) & TV/Radio Studios

### Broadcast Platforms · Four Year Study Plan
• Year 1: Introduction to Mass Communication, Media Writing 1, Photography & Visual Storytelling, Communication Theories, Media History, Digital Literacy, Academic English.
• Year 2: Radio Production Basics, Television Studio Operations, Scriptwriting for Broadcast, Audio & Video Editing, Media Law & Ethics, Research Methods.
• Year 3: Documentary Production, Broadcast News & Anchoring, Directing for TV & Streaming, Lighting & Cinematography, Podcasting & Webcasting Platforms.
• Year 4: Advanced Multi Camera Production, Media Entrepreneurship & AI in Media, Broadcast Programming & Management, Internship, Senior Graduation Media Project.

### Multimedia Journalism · Four Year Study Plan
• Year 1: Introduction to Mass Communication, Media Writing, Visual Storytelling, Communication Theories, Egyptian & International Media, Academic English.
• Year 2: News Reporting & Interviewing, Feature Writing, Photojournalism, Digital Media Design, Media Law & Ethics, Communication Research.
• Year 3: Data & Investigative Journalism, Mobile Journalism (MoJo), Social Media Content Strategy, Online Newsroom & Editing, Specialized Reporting.
• Year 4: AI Assisted Journalism & Fact Checking, Cross Platform Storytelling, Editorial Leadership, Media Analytics, Senior Graduation Journalism Project.

### Strategic Communication (PR & Advertising) · Four Year Study Plan
• Year 1: Introduction to Mass Communication, Media Writing, Visual Communication, Communication Theories, Psychology of Persuasion, Academic English.
• Year 2: Principles of Public Relations, Principles of Advertising, Copywriting, Consumer Insights, Media Law & Ethics, Communication Research.
• Year 3: Corporate Communication & Reputation Management, Digital Advertising & Media Buying, Crisis Communication, Brand Storytelling, Event Management.
• Year 4: Integrated Marketing Campaigns, Public Affairs & NGO Communication, Agency Management & Pitching, AI in Advertising, Senior Graduation Campaign Project.

## Faculty of Arts and Design (4 year plan)
University of Bedfordshire dual degree · Building E (Building 5), Building G Exhibitions & Building 6 Workshops

### Interior Design · Four Year Study Plan
• Year 1 (Foundation): Drawing & Sketching, Color Theory, 2D & 3D Design Principles, Art & Design History, Technical Drawing, Digital Design Basics, Academic English.
• Year 2: Interior Design Studio 1 & 2, Materials & Finishes, Lighting Design, Architectural CAD & 3D Visualization, Ergonomics & Human Scale.
• Year 3: Residential & Commercial Interior Studios, Furniture Design, Building Systems & Acoustics, Sustainable Interior Design, Working Drawings & Costing.
• Year 4: Hospitality & Exhibition Space Design, Adaptive Reuse, Professional Practice & Portfolio, Graduation Interior Design Project 1 & 2.

### Graphic & Media Arts · Four Year Study Plan
• Year 1 (Foundation): Drawing & Illustration, Color Theory, Typography Basics, 2D/3D Design, Art History, Digital Imaging, Academic English.
• Year 2: Typography 2, Visual Identity & Logo Design, Editorial & Publication Design, Illustration, Photography, Motion Graphics Basics.
• Year 3: Packaging Design, UI/UX & Interactive Media, 2D/3D Animation, Advertising Design, Brand Experience Systems, Design Research.
• Year 4: Transmedia Storytelling, Creative Direction, Digital Portfolio & Exhibition, Professional Practice, Senior Graduation Project 1 & 2.

### Fashion Design · Four Year Study Plan
• Year 1 (Foundation): Drawing, Color Theory, 2D/3D Design, History of Art & Costume, Basic Sewing & Textiles, Academic English.
• Year 2: Pattern Making 1 & 2, Draping, Fashion Illustration, Textile Science, Garment Construction, CAD for Fashion.
• Year 3: Ready to Wear & Haute Couture Studios, Fashion Styling & Photography, Knitwear & Surface Design, Fashion Marketing & Merchandising.
• Year 4: Sustainable Fashion, Collection Development, Fashion Show Production & Brand Management, Senior Graduation Collection Project.

### Cinema, Theatre & Product Design · Four Year Study Plan
• Year 1 (Foundation): Drawing, Color Theory, 3D Form & Modeling, Art History, Technical Drawing, Digital Tools, Academic English.
• Year 2: Set & Scenography Basics, Industrial & Product Modeling, Workshop Fabrication (Building 6), Lighting & Mood Studies, Materials Technology.
• Year 3: Film & Theatre Production Design, Costume & Props Design, Landscape & Environmental Design, 3D Prototyping & Rendering.
• Year 4: Advanced Scenography / Product Studio, Exhibition Design (Building G), Professional Practice & Portfolio, Senior Graduation Project.

## Faculty of Languages (4 year plan)
University of Bedfordshire dual degree · Building A (Building 1)

### Translation & Simultaneous Interpretation · Four Year Study Plan
• Year 1: Academic English Writing, Phonetics & Phonology, Introduction to Linguistics, Arabic Grammar & Style, Second Foreign Language 1, World Literature.
• Year 2: Theories of Translation, General Translation (EN/AR), Contrastive Linguistics, Morphology & Syntax, Sight Translation, Second Foreign Language 2.
• Year 3: Legal & Diplomatic Translation, Media & Literary Translation, Consecutive Interpretation, Audiovisual & Subtitling Translation, CAT Tools & Localization.
• Year 4: Simultaneous Interpretation (Conference Lab), Specialized Technical & Economic Translation, Post Editing & AI Translation Tools, Graduation Translation Project.

### English Language, Linguistics & Literature · Four Year Study Plan
• Year 1: Academic Writing, Phonetics, Introduction to Linguistics, Survey of English Literature, Arabic Rhetoric, Second Foreign Language 1.
• Year 2: Syntax & Semantics, Sociolinguistics, Drama & Poetry Studies, Modern Novel, Discourse Analysis, Second Foreign Language 2.
• Year 3: Applied Linguistics, Psycholinguistics, Literary Criticism & Theory, Shakespeare & Comparative Literature, Teaching English (TEFL/TESOL) Methods.
• Year 4: Pragmatics & Corpus Linguistics, Postcolonial & Contemporary Literature, Research Methodology, Senior Graduation Research Project.

## Faculty of Nutrition and Food Technology (4 year plan)
University of Greenwich dual degree · Scientific Labs Complex

### Nutrition Program · Four Year Study Plan
• Year 1: General Biology, General & Organic Chemistry, Human Anatomy & Physiology, Fundamentals of Human Nutrition, Biostatistics, Academic English.
• Year 2: Biochemistry, Food Microbiology, Macronutrients & Micronutrients, Food Composition & Preparation, Nutrition Through the Life Cycle.
• Year 3: Nutritional Assessment, Clinical Nutrition 1 (Metabolic & GI Disorders), Sports Nutrition, Community & Public Health Nutrition, Nutritional Epidemiology.
• Year 4: Clinical Nutrition 2 (Renal, Oncology & Critical Care), Diet Therapy & Meal Planning, Nutrition Counseling & Ethics, Clinical Training, Graduation Project.

### Food Technology Program · Four Year Study Plan
• Year 1: General Biology, General & Organic Chemistry, Physics, Fundamentals of Food Science, Biostatistics, Academic English.
• Year 2: Food Biochemistry, Food Microbiology, Food Chemistry & Analysis, Principles of Food Processing & Preservation, Unit Operations.
• Year 3: Dairy, Meat & Cereal Technology, Food Packaging & Shelf Life, Food Toxicology, Sensory Evaluation, HACCP & Food Safety Systems.
• Year 4: Food Quality Assurance & ISO 22000, Functional Foods & Product Development, Food Plant Design & Management, Industrial Training, Graduation Project.
